// src/index.js
import { LitElement, html, css } from 'https://unpkg.com/lit@2.7.5/index.js?module';
import * as THREE from 'https://unpkg.com/three@0.158.0/build/three.module.js';

class MyElement extends LitElement {
  static styles = css`
    :host {
      display: block;
      width: 100vw;
      height: 100vh;
    }
    canvas {
      display: block;
    }
  `;

  constructor() {
    super();
    this.particles = [];
    this.gravity = 0.01;
    this.colors = [
      [1, 0, 0], [0, 1, 0], [0, 0, 1],
      [1, 1, 0], [1, 0, 1], [0, 1, 1]
    ];
  }

  firstUpdated() {
    this.initThree();
  }

  initThree() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, this.offsetWidth / this.offsetHeight, 0.1, 1000);
    this.camera.position.z = 5;

    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.renderer.setSize(this.offsetWidth, this.offsetHeight);
    this.shadowRoot.appendChild(this.renderer.domElement);

    this.addEventListener('click', (e) => this.createFirework(e));
    window.addEventListener('resize', () => this.onResize());

    this.animate();
  }

  createFirework(e) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const count = 100;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const velocities = [];
    const baseColor = this.colors[Math.floor(Math.random() * this.colors.length)];

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      positions[i3] = x * 5;
      positions[i3 + 1] = y * 5;
      positions[i3 + 2] = 0;

      colors[i3] = baseColor[0];
      colors[i3 + 1] = baseColor[1];
      colors[i3 + 2] = baseColor[2];

      velocities.push({
        x: (Math.random() - 0.5) * 0.3,
        y: (Math.random() - 0.5) * 0.3 + 0.2,
        z: (Math.random() - 0.5) * 0.3
      });
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.1,
      vertexColors: true,
      transparent: true,
      blending: THREE.AdditiveBlending
    });

    const points = new THREE.Points(geometry, material);
    this.scene.add(points);

    this.particles.push({ points, velocities, geometry });
  }

  onResize() {
    this.camera.aspect = this.offsetWidth / this.offsetHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(this.offsetWidth, this.offsetHeight);
  }

  animate() {
    requestAnimationFrame(() => this.animate());

    this.particles.forEach((p, index) => {
      const pos = p.geometry.attributes.position.array;

      for (let i = 0; i < pos.length; i += 3) {
        const idx = i / 3;
        pos[i] += p.velocities[idx].x;
        pos[i + 1] += p.velocities[idx].y;
        pos[i + 2] += p.velocities[idx].z;
        p.velocities[idx].y -= this.gravity;
      }

      p.geometry.attributes.position.needsUpdate = true;
    });

    this.renderer.render(this.scene, this.camera);
  }

  render() {
    return html``;
  }
}

customElements.define('my-element', MyElement);
