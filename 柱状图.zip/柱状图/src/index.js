import * as THREE from 'three';

// 场景和渲染器
const scene = new THREE.Scene();
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setClearColor(0xffffff);
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// 正交相机设置
const aspect = window.innerWidth / window.innerHeight;
const viewSize = 15;
const camera = new THREE.OrthographicCamera(
  -viewSize * aspect / 2, viewSize * aspect / 2,
  viewSize / 2, -viewSize / 2,
  0.1, 1000
);
camera.position.set(0, viewSize * 0.4, 10);
camera.lookAt(0, viewSize * 0.3, 0);

// 添加光源
scene.add(new THREE.AmbientLight(0x404040));
const dirLight = new THREE.DirectionalLight(0xffffff, 0.5);
dirLight.position.set(1, 1, 1).normalize();
scene.add(dirLight);

// 数据与参数
const barData = [
  { label: '袜子', value: 5 },
  { label: 'T恤', value: 20 },
  { label: '短裙', value: 80 },
  { label: '裤子', value: 50 },
  { label: '运动鞋', value: 10 },
  { label: '衬衫', value: 100 },
];
const barWidth = 1;
const barGap = 0.5;
const maxHeight = 10;
const totalWidth = barData.length * (barWidth + barGap) - barGap;
const startX = -totalWidth / 2 + barWidth / 2;

// 坐标轴起点
const origin = new THREE.Vector3(startX - barWidth / 2, 0, 0);

// 画坐标轴线函数
function createAxis(axis, length, color) {
  const points = [origin.clone()];
  if (axis === 'x') points.push(new THREE.Vector3(origin.x + length, origin.y, origin.z));
  else if (axis === 'y') points.push(new THREE.Vector3(origin.x, origin.y + length, origin.z));
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({ color });
  return new THREE.Line(geometry, material);
}

// 添加X轴和Y轴
scene.add(createAxis('x', maxHeight + 2, 0x000000));
scene.add(createAxis('y', maxHeight + 2, 0x000000));

// 标签容器和标签管理
const labelContainer = document.getElementById('label-container');
const labels = [];

// 创建标签
function createLabel(text, pos3D) {
  const div = document.createElement('div');
  div.className = 'label';
  div.textContent = text;
  labelContainer.appendChild(div);
  labels.push({ element: div, position3D: pos3D });
}

// 添加Y轴刻度和标签
const yTicks = 5;
for (let i = 0; i <= yTicks; i++) {
  const val = (i / yTicks) * 100;
  const yPos = (val / 100) * maxHeight;
  // 刻度线
  const tickGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(origin.x - 0.3, yPos, 0),
    new THREE.Vector3(origin.x, yPos, 0)
  ]);
  const tick = new THREE.Line(tickGeo, new THREE.LineBasicMaterial({ color: 0x000000 }));
  scene.add(tick);
  // 标签
  createLabel((i * 20).toString(), new THREE.Vector3(origin.x - 0.5, yPos, 0));
}

// 添加X轴刻度和标签
barData.forEach((item, i) => {
  const xPos = startX + i * (barWidth + barGap);
  // 刻度线
  const tickGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(xPos, 0, 0),
    new THREE.Vector3(xPos, 0.3, 0)
  ]);
  const tick = new THREE.Line(tickGeo, new THREE.LineBasicMaterial({ color: 0x000000 }));
  scene.add(tick);
  // 标签
  createLabel(item.label, new THREE.Vector3(xPos, -0.7, 0));
});

// 画柱状条
barData.forEach((item, i) => {
  const valueRatio = item.value / 100;
  const xPos = startX + i * (barWidth + barGap);

  // 彩色部分高度
  const colorHeight = maxHeight * valueRatio;
  if (colorHeight > 0) {
    const geometry = new THREE.PlaneGeometry(barWidth, colorHeight);
    const colors = new Float32Array(geometry.attributes.position.count * 3);
    const colorBottom = new THREE.Color(0x00ff00);
    const colorMiddle = new THREE.Color(0xffff00);
    const colorTop = new THREE.Color(0xff0000);
    const tempColor = new THREE.Color();

    for (let i = 0; i < geometry.attributes.position.count; i++) {
      const y = geometry.attributes.position.getY(i) + colorHeight / 2;
      const norm = y / maxHeight;
      if (norm < 0.5) {
        tempColor.copy(colorBottom).lerp(colorMiddle, norm / 0.5);
      } else {
        tempColor.copy(colorMiddle).lerp(colorTop, (norm - 0.5) / 0.5);
      }
      colors[i * 3] = tempColor.r;
      colors[i * 3 + 1] = tempColor.g;
      colors[i * 3 + 2] = tempColor.b;
    }
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const material = new THREE.MeshBasicMaterial({ vertexColors: true });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(xPos, colorHeight / 2, 0);
    scene.add(mesh);
  }

  // 灰色部分
  const greyHeight = maxHeight - colorHeight;
  if (greyHeight > 0) {
    const greyGeo = new THREE.PlaneGeometry(barWidth, greyHeight);
    const greyMat = new THREE.MeshBasicMaterial({ color: 0x808080 });
    const greyMesh = new THREE.Mesh(greyGeo, greyMat);
    greyMesh.position.set(xPos, colorHeight + greyHeight / 2, 0);
    scene.add(greyMesh);
  }
});

// 动画循环
function animate() {
  requestAnimationFrame(animate);

  // 更新标签位置
  labels.forEach(({ element, position3D }) => {
    const pos = position3D.clone();
    pos.project(camera);
    const x = (pos.x + 1) / 2 * window.innerWidth;
    const y = (1 - pos.y) / 2 * window.innerHeight;
    element.style.left = `${x}px`;
    element.style.top = `${y}px`;
    element.style.display = pos.z > 1 ? 'none' : '';
  });

  renderer.render(scene, camera);
}
animate();

// 窗口调整
window.addEventListener('resize', () => {
  const newAspect = window.innerWidth / window.innerHeight;
  camera.left = -viewSize * newAspect / 2;
  camera.right = viewSize * newAspect / 2;
  camera.top = viewSize / 2;
  camera.bottom = -viewSize / 2;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
