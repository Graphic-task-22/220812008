import { LitElement, html, css } from 'lit';
import * as THREE from 'three';
import { createNoise2D } from 'simplex-noise';

class MyMountains extends LitElement {
  static styles = css`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `;

  constructor() {
    super();
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.plane = null;
    this.noise2D = createNoise2D();
    this.scrollOffset = 0;
  }

  firstUpdated() {
    this.initScene();
  }

  initScene() {
    this.scene = new THREE.Scene();

    this.camera = new THREE.PerspectiveCamera(
      70,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    this.camera.position.set(0, 80, 120);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.shadowRoot.appendChild(this.renderer.domElement);

    this.createTerrain();

    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    const light = new THREE.DirectionalLight(0xffffff, 0.8);
    light.position.set(1, 1, 1);
    this.scene.add(ambient, light);

    window.addEventListener('resize', () => this.handleResize());
    this.animate();
  }

  createTerrain() {
    const geometry = new THREE.PlaneGeometry(200, 200, 100, 100);

    // 初始化所有 Z 值
    const positions = geometry.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);
      const z = this.noise2D(x * 0.05, y * 0.05) * 20;
      positions.setZ(i, z);
    }

    const material = new THREE.MeshStandardMaterial({
      wireframe: true,
      vertexColors: false,
      color: 0x66ccff,
    });

    this.plane = new THREE.Mesh(geometry, material);
    this.plane.rotation.x = -Math.PI / 2;
    this.scene.add(this.plane);
  }

  updateTerrain() {
    const positions = this.plane.geometry.attributes.position;
    const time = Date.now() * 0.0005;
    this.scrollOffset += 0.01; // 控制向前移动的速度

    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);
      const z = this.noise2D(x * 0.05, (y + this.scrollOffset * 20) * 0.05) * 10;
      positions.setZ(i, z);
    }

    positions.needsUpdate = true;
  }

  handleResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.updateTerrain();
    this.renderer.render(this.scene, this.camera);
  }

  render() {
    return html``;
  }
}

customElements.define('my-mountains', MyMountains);
